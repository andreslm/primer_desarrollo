/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejecucionbatchmotor.util;

import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author b05745a
 */
public class Archivo_1_11 {
    
    private final double TIPO_ID = 100000000000L;
    
    public void Archivo_1_11() {}
    
    /**
     * Crear archivo 1-11 para obtener informacion de buro
     * @param baseEjecutar
     * @return 
     */
    public boolean crearArchivo(String baseEjecutar) {
        
        String pathArchivo = "../temporales/" + baseEjecutar;
        ArrayList<String> filasArchivo = new ArrayList<>();
        ArrayList<String> filasArchivo_1_11 = new ArrayList<>();
        ProcesarArchivoTexto procesarArchivoTexto = new ProcesarArchivoTexto();
        
        filasArchivo = procesarArchivoTexto.leerArchivoTxt(new File(pathArchivo));
        
        int numeroFila = 1;
        for(String fila: filasArchivo) {
            if(numeroFila > 1) {
                String[] datos = fila.split("\\;");                
                double tipoId = Double.parseDouble(datos[0]);                
                tipoId = tipoId * TIPO_ID;                                
                double dato = tipoId + Double.parseDouble(datos[1]);                
                filasArchivo_1_11.add(String.format("%.0f", dato));
            } else {
                numeroFila++;
            }
        }
        
        procesarArchivoTexto.crearArchivo(pathArchivo.substring(0, pathArchivo.length() - 4) + ".prn", filasArchivo_1_11);
        
        return true;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejecucionbatchmotor.util;

/**
 *
 * @author e10517a
 */
public enum EnumEstrategias {
    
    
    _24482("24482","Bancamia_Bancamiapolcr_vr2"),
    _15350("15350","Decisor_Politicas_De_Credito_2");
    
    
    private String idEstrategia;
    private String nombreEstrategia;

    private EnumEstrategias(String idEstrategia,String nombreEstrategia){
        this.idEstrategia=idEstrategia;
        this.nombreEstrategia=nombreEstrategia;
        
    }
    
    public static EnumEstrategias estrategiaByID(String idEstrategai){
        for(EnumEstrategias valor : EnumEstrategias.values()){
            if(idEstrategai.contains(valor.getIdEstrategia())){
                return valor;
            }
        } 
        return null;
    }

    public String getIdEstrategia() {
        return idEstrategia;
    }

    public void setIdEstrategia(String idEstrategia) {
        this.idEstrategia = idEstrategia;
    }

    public String getNombreEstrategia() {
        return nombreEstrategia;
    }

    public void setNombreEstrategia(String nombreEstrategia) {
        this.nombreEstrategia = nombreEstrategia;
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejecucionbatchmotor.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author b05745a
 */
public class ProcesarArchivoTexto {
    
    String PATH_FILE_BATCH = "../temporales/";

    public void ProcesarArchivoTexto() {}

    /**
     * Metodo que crea archivo de texto
     * @param path
     * @param listaFilas 
     */
    public void crearArchivo(String path, ArrayList<String> listaFilas) {
        File archivo = new File(path);
        BufferedWriter bw;

        if (archivo.exists()) {
            archivo.delete();
        }

        try {
            bw = new BufferedWriter(new FileWriter(archivo));
            Iterator<String> iterador = listaFilas.iterator();
            
            while (iterador.hasNext()) {
                String fila = iterador.next();
                bw.write(fila);
                bw.newLine();
            }
            
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(ProcesarArchivoTexto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * Metodo para leer archivo de texto
     * @param archivoTexto
     * @return ArrayList<String>
     */
    public ArrayList<String> leerArchivoTxt(File archivoTexto) {
        
        /*Lectura*/
        FileReader fr = null;
        BufferedReader br = null;
        ArrayList<String> filasArchivo = new ArrayList<>();
        
        try {
            
            fr = new FileReader(archivoTexto);
            br = new BufferedReader(fr);
            String linea = "";
            System.out.println("Leyendo base");
            while ((linea = br.readLine()) != null) {
                Runtime garbage = Runtime.getRuntime();
                garbage.gc();
                filasArchivo.add(linea);
            }
            System.out.println("Fin lectura base");
        } catch (FileNotFoundException ex) {
            System.out.println(this.getClass().getName()+" - "+ ex);
        } catch (IOException ex) {
            System.out.println(this.getClass().getName()+" - "+ ex);
        } finally {
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta 
            // una excepcion.
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (Exception e2) {
                System.out.println(this.getClass().getName()+" - "+ e2);
            }
        }
        
        return filasArchivo;
    }
    
    

    public ArrayList<Integer> validarInconsistencias(String pathArchivoBuro) {
        ArrayList<Integer> listaInvalidos = new ArrayList<>();
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        String pathArchivoInconsistencias = pathArchivoBuro.substring(0, pathArchivoBuro.length() - 4) + ".inc";
        try {
        
            archivo = new File(pathArchivoInconsistencias);
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            // Lectura del fichero
            String linea;
            while ((linea = br.readLine()) != null) {
                listaInvalidos.add(Integer.parseInt(linea.substring(2, 13)));
            }

        } catch (FileNotFoundException ex) {
            System.out.println(this.getClass().getName()+" - "+ ex);
        } catch (IOException ex) {
            System.out.println(this.getClass().getName()+" - "+ ex);
        }

        return listaInvalidos;
    }
    
 
    public void crearArchivoBatchSIS(String path, ArrayList<String> listaDatos) {
        
        //File archivo = new File("C:\\Users\\e10517a\\Documents\\NetBeansProjects\\EjecucionBatchMotor\\BANCAMIAPOLCR_VR2_565656\\SIS\\SIS_"+path);
        File archivo = new File(path);
        BufferedWriter bw;
        try {
            bw = new BufferedWriter(new FileWriter(archivo));
            for (String linea : listaDatos) {
                bw.write(linea);
                bw.newLine();
            }
            bw.close();
        } catch (IOException ex) {
            System.out.println(this.getClass().getName()+" - "+ ex);
        }
    }
    
    public void crearArchivoBatchSISContinuo(String path, String lineaSIS) {
        
        BufferedWriter bw = null;
        FileWriter fw = null;
        
        //File archivo = new File("C:\\Users\\e10517a\\Documents\\NetBeansProjects\\EjecucionBatchMotor\\FINANDINA\\SIS\\SIS_"+path);
        
        try {
            /*
            if (!archivo.exists()) {
                archivo.createNewFile();
            }*/
            fw = new FileWriter("C:\\Users\\b05745a\\Documents\\EjecucionBatchMotor\\FINANDINA\\SIS\\SIS_"+path, true);
            bw = new BufferedWriter(fw);
            bw.write(lineaSIS);
            bw.newLine();
        } catch (IOException ex) {
            System.out.println(this.getClass().getName()+" - "+ ex);
        }finally{
            try {
                if(bw!=null){
                   bw.flush();
                   bw.close();
                }
                if(fw!=null){
                   fw.close();
                }
                
                
            } catch (IOException ex) {
                System.out.println(ProcesarArchivoTexto.class.getName()+" >=> "+ ex);
            }
        }
    }
    
}

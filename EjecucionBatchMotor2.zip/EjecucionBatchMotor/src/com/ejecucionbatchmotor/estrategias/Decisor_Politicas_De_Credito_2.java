/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejecucionbatchmotor.estrategias;

import com.ejecucionbatchmotor.util.ProcesarArchivoTexto;
import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import resources.finandina.Diccionario_Salida_15350;
import resources.finandina._15350_DECISOR_POLITICAS_DE_CREDITO_2;


/**
 *
 * @author e10517a
 */
public class Decisor_Politicas_De_Credito_2 {
    //String PATH_FILE_BATCH = "../temporales/";
    //String PATH_FILE_BATCH_OUT = "../temporales/";
    String PATH_FILE_BATCH = "C:\\Users\\e10517a\\Documents\\NetBeansProjects\\EjecucionBatchMotor\\temporales\\";
    String PATH_FILE_BATCH_OUT = "C:\\Users\\e10517a\\Documents\\NetBeansProjects\\EjecucionBatchMotor\\temporales\\";
    
    
    LinkedHashMap<String, String> estructuraSIS = new LinkedHashMap<>();
    
    String encabezadosSIS;
    String encabezadoSalidaBatch;
    
    public Decisor_Politicas_De_Credito_2() {
        
        if(estructuraSIS==null || estructuraSIS.isEmpty()){
            _15350_DECISOR_POLITICAS_DE_CREDITO_2 _15350 = new _15350_DECISOR_POLITICAS_DE_CREDITO_2();
            estructuraSIS = _15350.getDICCIONARIO_ENTRADA_15350();
            encabezadosSIS = _15350.encabezadoSIS().toString();
            encabezadoSalidaBatch = _15350.encabezadoSalidaBatch().toString();
        }
    }
    
    public void crearArchivoBatchSIS(String informacionBuro) {
        
        ProcesarArchivoTexto procesarArchivo = new ProcesarArchivoTexto();
        ArrayList<String> filasInformacionBuro = procesarArchivo.leerArchivoTxt(new File(PATH_FILE_BATCH+informacionBuro));
        
        BigDecimal identificacion = BigDecimal.ZERO;
        BigDecimal tipoId = BigDecimal.ZERO;
        String nombre = "";
        int i = 0;
        
        ArrayList<String> listaArchivo = new ArrayList<String>();
        
        for(String filaBuro : filasInformacionBuro){
            String lineaArchivo = "";
            String[] infoBuro = filaBuro.split("\\|");
            Runtime garbage = Runtime.getRuntime();
            garbage.gc();
            //0:TIPO_ID
            if(i > 0){
                
                
                tipoId = new BigDecimal(infoBuro[0]);
                identificacion = new BigDecimal(infoBuro[1]);
                nombre=infoBuro[2] ;
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMYPN249", tipoId.toString().trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMYPN250", identificacion.toString().trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.ExternasAlfanumericas.DUMYET250", nombre.trim());
                //Fr_Monto_del_Credito
                estructuraSIS.put("Formulario.Estandar.SpareFormularioNumericaSparformn001",infoBuro[3].trim());

                estructuraSIS.put("Buro.Scores.AciertaMasterFinanciero.C02SCR042TO", infoBuro[4].trim());
                estructuraSIS.put("Buro.Demograficos.Demograficos.C00DEM003TO", infoBuro[5].trim());
                estructuraSIS.put("Buro.Demograficos.Demograficos.C00DEM027TO", infoBuro[6].trim());
                estructuraSIS.put("Buro.Demograficos.Demograficos.C00DEM03400", infoBuro[7].trim());
                estructuraSIS.put("Buro.Endeudamiento.SaldosDeProductosALaFecha.C01END001CC", infoBuro[8].trim());
                estructuraSIS.put("Buro.Endeudamiento.SaldosDeProductosALaFecha.C01END001HP", infoBuro[9].trim());
                estructuraSIS.put("Buro.Endeudamiento.SaldosDeProductosALaFecha.C01END001IN", infoBuro[10].trim());
                estructuraSIS.put("Buro.Endeudamiento.SaldosDeProductosALaFecha.C01END001OT", infoBuro[11].trim());
                estructuraSIS.put("Buro.Endeudamiento.SaldosDeProductosALaFecha.C01END001RO", infoBuro[12].trim());
                estructuraSIS.put("Buro.Endeudamiento.SaldosDeProductosALaFecha.C01END001VE", infoBuro[13].trim());
                estructuraSIS.put("Buro.Endeudamiento.CuotaPorProductoALaFecha.C01END005CC", infoBuro[14].trim());
                estructuraSIS.put("Buro.Endeudamiento.CuotaPorProductoALaFecha.C01END005HP", infoBuro[15].trim());
                estructuraSIS.put("Buro.Endeudamiento.CuotaPorProductoALaFecha.C01END005IN", infoBuro[16].trim());
                estructuraSIS.put("Buro.Endeudamiento.CuotaPorProductoALaFecha.C01END005OT", infoBuro[17].trim());
                estructuraSIS.put("Buro.Endeudamiento.CuotaPorProductoALaFecha.C01END005RO", infoBuro[18].trim());
                estructuraSIS.put("Buro.Endeudamiento.CuotaPorProductoALaFecha.C01END005VE", infoBuro[19].trim());
                estructuraSIS.put("Buro.Endeudamiento.CupoTotalALaFecha.C01END007RO", infoBuro[20].trim());
                estructuraSIS.put("Buro.Endeudamiento.Historico9Meses.C01END089RO", infoBuro[21].trim());
                estructuraSIS.put("Buro.Experiencia.AperturaDeProductoMasAntiguo.C01EXP001RO", infoBuro[22].trim());
                estructuraSIS.put("Buro.Experiencia.AperturaDeProductoMasAntiguo.C01EXP003CC", infoBuro[23].trim());
                estructuraSIS.put("Buro.Experiencia.EdadPromedioDeProtafolios.C01EXP006IN", infoBuro[24].trim());
                estructuraSIS.put("Buro.Experiencia.ProductosEnLibrosHasta12Meses.C01EXP008RO", infoBuro[25].trim());
                estructuraSIS.put("Buro.Consultas.Consultas.C01INQ017TO", infoBuro[26].trim());
                estructuraSIS.put("Buro.Consultas.Consultas.C01INQ025TO", infoBuro[27].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079CC", infoBuro[28].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079CO", infoBuro[29].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079HP", infoBuro[30].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079IN", infoBuro[31].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079OT", infoBuro[32].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079RO", infoBuro[33].trim());
                estructuraSIS.put("Buro.Morosidad.CastigoMasReciente.C01MOR079VE", infoBuro[34].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111CC", infoBuro[35].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111HP", infoBuro[36].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111IN", infoBuro[37].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111OT", infoBuro[38].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111RO", infoBuro[39].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111VE", infoBuro[40].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos24Meses.C01MOR117CC", infoBuro[41].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos24Meses.C01MOR117HP", infoBuro[42].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos24Meses.C01MOR117IN", infoBuro[43].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos24Meses.C01MOR117OT", infoBuro[44].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos24Meses.C01MOR117RO", infoBuro[45].trim());
                estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos24Meses.C01MOR117VE", infoBuro[46].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductos.C01NUM001HP", infoBuro[47].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosAbiertos.C01NUM002RO", infoBuro[48].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019CC", infoBuro[49].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019CO", infoBuro[50].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019HP", infoBuro[51].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019IN", infoBuro[52].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019OT", infoBuro[53].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019RO", infoBuro[54].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosRecuperados.C01NUM019VE", infoBuro[55].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosEmbargados.C01NUM022AH", infoBuro[56].trim());
                estructuraSIS.put("Buro.Contadores.NumeroDeProductosEmbargados.C01NUM022CT", infoBuro[57].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionCReporteMasReciente.C02SUP007TO", infoBuro[58].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionC2doReporteReciente.C02SUP008TO", infoBuro[59].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionC3erReporteReciente.C02SUP009TO", infoBuro[60].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionDReporteMasReciente.C02SUP010TO", infoBuro[61].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionD2doReporteReciente.C02SUP011TO", infoBuro[62].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionD3erReporteReciente.C02SUP012TO", infoBuro[63].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionEReporteMasReciente.C02SUP013TO", infoBuro[64].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionE2doReporteReciente.C02SUP014TO", infoBuro[65].trim());
                estructuraSIS.put("Buro.Super.ProductosCalificacionE3erReporteReciente.C02SUP015TO", infoBuro[66].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN01", infoBuro[67].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN02", infoBuro[68].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN38", infoBuro[69].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN39", infoBuro[70].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN40", infoBuro[71].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN41", infoBuro[72].trim());
                
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN69", infoBuro[73].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN70", infoBuro[74].trim());
                estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN71", infoBuro[75].trim());
                
                   
                // Escritura de archivo txt Batch SIS por filas
                for (Map.Entry<String, String> entry : estructuraSIS.entrySet()) {
                    if (!entry.getKey().equals("null")) {
                        lineaArchivo = lineaArchivo + entry.getValue() + "|";
                    }
                }
                

                lineaArchivo = lineaArchivo.substring(0, lineaArchivo.length());
                //procesarArchivo.crearArchivoBatchSISContinuo(informacionBuro, lineaArchivo);

            }else{
                lineaArchivo = encabezadosSIS;
                //procesarArchivo.crearArchivoBatchSISContinuo(informacionBuro, encabezadosSIS);
            }
            
            if((i%10000)==0){
                System.out.println("Registro procesado: "+i);
            }
            
            i++;
            listaArchivo.add(lineaArchivo);
        }
        
        procesarArchivo.crearArchivoBatchSIS(PATH_FILE_BATCH+"SIS_" + informacionBuro, listaArchivo);
    }
    
    public void crearArchivoSalidaBatch(String informacionBuro){
        
        ProcesarArchivoTexto procesarArchivo = new ProcesarArchivoTexto();
        ArrayList<String> filasInformacionSalida = procesarArchivo.leerArchivoTxt(new File(PATH_FILE_BATCH_OUT+informacionBuro));
        
        LinkedHashMap<String, String> archivoSalidaBatchSIS = new LinkedHashMap<>();
        int i = 0;
        
        ArrayList<String> listaArchivo = new ArrayList<String>();
        listaArchivo.add(encabezadoSalidaBatch);
        System.out.println("Inicio escritura archivo de salida");
        for(String filaBuro : filasInformacionSalida){
            String lineaArchivo = "";
            
            if(filaBuro.contains("񯳼")){
                filaBuro = filaBuro.replaceAll("񯳼", "ños |");
                filaBuro = filaBuro.replaceAll("Validar Edad Mayor A 21 A", "Validar Edad Mayor A 21 Años");
            }
            
            String[] infoSalida = filaBuro.split("\\|");
            Runtime garbage = Runtime.getRuntime();
            garbage.gc();
        
            if(i > 0){
                
                if(infoSalida.length > 1){
                
                    LinkedHashMap<String, String> estructuraSalidaSIS = new LinkedHashMap<>();
                    Diccionario_Salida_15350  Salida_15350 = new Diccionario_Salida_15350();
                    Salida_15350.setValues(infoSalida);
                    estructuraSalidaSIS = Salida_15350.get15350_DECISOR_POLITICAS_DE_CREDITO_2_SALIDA();

                    archivoSalidaBatchSIS.put("TIPO_ID", estructuraSalidaSIS.get("Buro.VariablesPersonalizadas.Numericas.DUMYPN249"));
                    archivoSalidaBatchSIS.put("ID", estructuraSalidaSIS.get("Buro.VariablesPersonalizadas.Numericas.DUMYPN250"));
                    archivoSalidaBatchSIS.put("APELLIDO", estructuraSalidaSIS.get("Buro.VariablesPersonalizadas.ExternasAlfanumericas.DUMYET250"));
                    archivoSalidaBatchSIS.put("Decision", !estructuraSalidaSIS.get("Clasificacion").trim().equals("")? estructuraSalidaSIS.get("Clasificacion").substring(0,1):"");
                    archivoSalidaBatchSIS.put("Score",  estructuraSalidaSIS.get("Puntaje"));
                    archivoSalidaBatchSIS.put("RESULTADO PROCESO REGISTRO",  "REGISTRO PROCESADO");
                    archivoSalidaBatchSIS.put("AciAConsumo",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin102"));
                    archivoSalidaBatchSIS.put("AciAFinanciero",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin099"));
                    archivoSalidaBatchSIS.put("AciATDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin103"));
                    archivoSalidaBatchSIS.put("Acierta Master Financiero",  estructuraSalidaSIS.get("Buro.Scores.AciertaMasterFinanciero.C02SCR042TO"));
                    archivoSalidaBatchSIS.put("CompraCartera_12",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin042"));
                    archivoSalidaBatchSIS.put("CompraCartera_24",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin043"));
                    archivoSalidaBatchSIS.put("CompraCartera_36",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin044"));
                    archivoSalidaBatchSIS.put("CompraCartera_48",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin045"));
                    archivoSalidaBatchSIS.put("CompraCartera_60",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin046"));
                    archivoSalidaBatchSIS.put("Cuotas_CC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin085"));
                    archivoSalidaBatchSIS.put("Cuotas_HP",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin086"));
                    archivoSalidaBatchSIS.put("Cuotas_OT",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin087"));
                    archivoSalidaBatchSIS.put("Cuotas_RO",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin088"));
                    archivoSalidaBatchSIS.put("DF_Portafolio",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin014"));
                    archivoSalidaBatchSIS.put("DF_Potencial",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin012"));
                    archivoSalidaBatchSIS.put("DF_Producto",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin013"));
                    archivoSalidaBatchSIS.put("DF_ProductoCC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin041"));
                    archivoSalidaBatchSIS.put("DF_Real",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin011"));
                    archivoSalidaBatchSIS.put("DisponibleInicial",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin016"));
                    archivoSalidaBatchSIS.put("EndPotencial",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin004"));
                    archivoSalidaBatchSIS.put("EndReal",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin003"));
                    archivoSalidaBatchSIS.put("FCPoten_CC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin080"));
                    archivoSalidaBatchSIS.put("FCPoten_HP",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin081"));
                    archivoSalidaBatchSIS.put("FCPoten_OT",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin082"));
                    archivoSalidaBatchSIS.put("FCPoten_RO",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin083"));
                    archivoSalidaBatchSIS.put("FCReal_CC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin076"));
                    archivoSalidaBatchSIS.put("FCReal_HP",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin077"));
                    archivoSalidaBatchSIS.put("FCReal_OT",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin078"));
                    archivoSalidaBatchSIS.put("FCReal_RO",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin079"));
                    archivoSalidaBatchSIS.put("FC_TDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin084"));
                    archivoSalidaBatchSIS.put("FacCompraADD",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin093"));
                    archivoSalidaBatchSIS.put("FacDisponibleAdd",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin015"));
                    archivoSalidaBatchSIS.put("FacRiesgoPotecial",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin064"));
                    archivoSalidaBatchSIS.put("FacRiesgoReal",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin063"));
                    archivoSalidaBatchSIS.put("GrupoR_P",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin104"));
                    archivoSalidaBatchSIS.put("GrupoR_T",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin105"));
                    archivoSalidaBatchSIS.put("Hipotecario",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin051"));
                    archivoSalidaBatchSIS.put("IngresosBasicos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin060"));
                    archivoSalidaBatchSIS.put("IngresosSMLMV",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin008"));
                    archivoSalidaBatchSIS.put("LimVecesPrestamas",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin095"));
                    archivoSalidaBatchSIS.put("LimVecesTDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin096"));
                    archivoSalidaBatchSIS.put("LimVecesTDC_2OF",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin098"));
                    archivoSalidaBatchSIS.put("LimVecesVehiculos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin094"));
                    archivoSalidaBatchSIS.put("LimVeces_CC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin097"));
                    archivoSalidaBatchSIS.put("MaximoCupoDeLaTarjeta",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin059"));
                    archivoSalidaBatchSIS.put("MesesCastigoReciente",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin062"));
                    archivoSalidaBatchSIS.put("MontoMaxPrestamas",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin066"));
                    archivoSalidaBatchSIS.put("MontoMaxTDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin067"));
                    archivoSalidaBatchSIS.put("MontoMaxTDC_ESP",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin068"));
                    archivoSalidaBatchSIS.put("MontoMaxVehiculos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin065"));
                    archivoSalidaBatchSIS.put("MontoMax_CC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin073"));
                    archivoSalidaBatchSIS.put("MontoMinPrestamas",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin070"));
                    archivoSalidaBatchSIS.put("MontoMinTDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin072"));
                    archivoSalidaBatchSIS.put("MontoMinVehiculos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin069"));
                    archivoSalidaBatchSIS.put("NodoRiesgo",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin101"));
                    archivoSalidaBatchSIS.put("NodoRiesgo_P",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin100"));
                    archivoSalidaBatchSIS.put("OfertaMinTDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin071"));
                    archivoSalidaBatchSIS.put("OfertaPrestamas_12",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin024"));
                    archivoSalidaBatchSIS.put("OfertaPrestamas_24",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin025"));
                    archivoSalidaBatchSIS.put("OfertaPrestamas_36",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin026"));
                    archivoSalidaBatchSIS.put("OfertaPrestamas_48",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin027"));
                    archivoSalidaBatchSIS.put("OfertaPrestamas_60",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin028"));
                    archivoSalidaBatchSIS.put("OfertaTDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin017"));
                    archivoSalidaBatchSIS.put("OfertaTDC_ESP",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin018"));
                    archivoSalidaBatchSIS.put("OfertaTDC_Prestamas",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin030"));
                    archivoSalidaBatchSIS.put("OfertaTDC_Vehiculos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin029"));
                    archivoSalidaBatchSIS.put("OfertaVehiculos_12",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin019"));
                    archivoSalidaBatchSIS.put("OfertaVehiculos_24",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin020"));
                    archivoSalidaBatchSIS.put("OfertaVehiculos_36",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin021"));
                    archivoSalidaBatchSIS.put("OfertaVehiculos_48",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin022"));
                    archivoSalidaBatchSIS.put("OfertaVehiculos_60",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin023"));
                    archivoSalidaBatchSIS.put("OtrosCreditos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin052"));
                    archivoSalidaBatchSIS.put("OtrosCreditos_in",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin053"));
                    archivoSalidaBatchSIS.put("OtrosCreditos_ve",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin054"));
                    archivoSalidaBatchSIS.put("Politica_CalificacionMRCOBCDE",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin040"));
                    archivoSalidaBatchSIS.put("Politica_Castigos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin039"));
                    archivoSalidaBatchSIS.put("Politica_Edad",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin031"));
                    archivoSalidaBatchSIS.put("Politica_Embargos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin037"));
                    archivoSalidaBatchSIS.put("Politica_Endeudamiento",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin032"));
                    archivoSalidaBatchSIS.put("Politica_Ingresos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin034"));
                    archivoSalidaBatchSIS.put("Politica_Mora30",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin035"));
                    archivoSalidaBatchSIS.put("Politica_Mora90",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin036"));
                    archivoSalidaBatchSIS.put("Politica_Recuperaciones",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin038"));
                    archivoSalidaBatchSIS.put("Politica_Score",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin033"));
                    archivoSalidaBatchSIS.put("RESPUESTA",  estructuraSalidaSIS.get("Clasificacion"));
                    archivoSalidaBatchSIS.put("Rango_Ingresos",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit001"));
                    archivoSalidaBatchSIS.put("Riesgo",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit012"));
                    archivoSalidaBatchSIS.put("Rotativos",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin050"));
                    archivoSalidaBatchSIS.put("SALDOS_CC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin089"));
                    archivoSalidaBatchSIS.put("SALDOS_HP",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin090"));
                    archivoSalidaBatchSIS.put("SALDOS_OT",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin092"));
                    archivoSalidaBatchSIS.put("SALDOS_RO",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin091"));
                    archivoSalidaBatchSIS.put("SaldosCliente (Sin HIPOTECARIO)",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin047"));
                    archivoSalidaBatchSIS.put("SaldosCompra",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin048"));
                    archivoSalidaBatchSIS.put("SalidaCausal1",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit002"));
                    archivoSalidaBatchSIS.put("SalidaCausal10",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit011"));
                    archivoSalidaBatchSIS.put("SalidaCausal2",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit003"));
                    archivoSalidaBatchSIS.put("SalidaCausal3",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit004"));
                    archivoSalidaBatchSIS.put("SalidaCausal4",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit005"));
                    archivoSalidaBatchSIS.put("SalidaCausal5",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit006"));
                    archivoSalidaBatchSIS.put("SalidaCausal6",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit007"));
                    archivoSalidaBatchSIS.put("SalidaCausal7",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit008"));
                    archivoSalidaBatchSIS.put("SalidaCausal8",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit009"));
                    archivoSalidaBatchSIS.put("SalidaCausal9",  estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit010"));
                    archivoSalidaBatchSIS.put("Servicio",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin049"));
                    archivoSalidaBatchSIS.put("SumaSaldosTodasObligFinanc",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin057"));
                    archivoSalidaBatchSIS.put("SumaSaldosTodasObligHipotecario",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin058"));
                    archivoSalidaBatchSIS.put("SumaSaldosTodasObligaciones",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin056"));
                    archivoSalidaBatchSIS.put("TasaModelar",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin074"));
                    archivoSalidaBatchSIS.put("TasaTDC",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin075"));
                    archivoSalidaBatchSIS.put("TotalPoliticasNeg",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin055"));
                    archivoSalidaBatchSIS.put("ValQuanto",  estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin061"));
                    
                    for (Map.Entry<String, String> entry : archivoSalidaBatchSIS.entrySet()) {
                        if (!entry.getKey().equals("null")) {
                            lineaArchivo = lineaArchivo + entry.getValue() + ";";
                        }
                    }

                    lineaArchivo = lineaArchivo.substring(0, lineaArchivo.length());
                    listaArchivo.add(lineaArchivo);
                    //procesarArchivo.crearArchivoBatchSISContinuo(nameFileSalida, lineaArchivo);
                }
                
            }/*else{
                procesarArchivo.crearArchivoBatchSISContinuo(nameFileSalida, encabezadoSalidaBatch);
            }*/
            i++;
            
        }
        procesarArchivo.crearArchivoBatchSIS(PATH_FILE_BATCH+"SALIDA_" + informacionBuro, listaArchivo);
        System.out.println("Finaliza escritura archivo::: SALIDA_" + informacionBuro);
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejecucionbatchmotor.estrategias;

import com.ejecucionbatchmotor.util.ProcesarArchivoTexto;
import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import resources.bancamia.Diccionario_Salida_24482;
import resources.bancamia._24482_BANCAMIAPOLCR_VR2;



/**
 *
 * @author b05745a
 */
public class Bancamia_Bancamiapolcr_vr2 {
    
    String PATH_FILE_BATCH = "../temporales/";
    //String PATH_FILE_BATCH = "C:\\Users\\e10517a\\Documents\\NetBeansProjects\\EjecucionBatchMotor\\temporales\\";
    String PATH_FILE_BATCH_OUT = "../temporales/";
    //String PATH_FILE_BATCH_OUT = "C:\\Users\\e10517a\\Documents\\NetBeansProjects\\EjecucionBatchMotor\\temporales\\";
    LinkedHashMap<String, String> estructuraSIS = new LinkedHashMap<>();
    
    String encabezadosSIS;
    String encabezadoSalidaBatch;
    
    public Bancamia_Bancamiapolcr_vr2() {
        
        if(estructuraSIS==null || estructuraSIS.isEmpty()){
            _24482_BANCAMIAPOLCR_VR2 _24482 = new _24482_BANCAMIAPOLCR_VR2();
            estructuraSIS = _24482.get_24482_BANCAMIAPOLCR_VR2();
            encabezadosSIS = _24482.encabezadoSIS().toString();
            encabezadoSalidaBatch = _24482.encabezadoSalidaBatch().toString();
        }
    }
    
    public void crearArchivoBatchSIS(String informacionBuro) {
        
        ProcesarArchivoTexto procesarArchivo = new ProcesarArchivoTexto();                
        ArrayList<String> filasInformacionBuro = procesarArchivo.leerArchivoTxt(new File(PATH_FILE_BATCH+informacionBuro));
        
        
        BigDecimal identificacion = BigDecimal.ZERO;
        BigDecimal tipoId = BigDecimal.ZERO;
        BigDecimal fr_Segmento = BigDecimal.ZERO;
        String nombre = "";
        int i = 0;
        
        ArrayList<String> listaDatosArchivoSIS = new ArrayList<>();
        //listaDatosArchivoSIS.add(encabezadosSIS);
        
        for(String filaBuro : filasInformacionBuro){
            String lineaArchivo = "";
            String[] infoBuro = filaBuro.split("\\|");
            Runtime garbage = Runtime.getRuntime();
            garbage.gc();

            //0:TIPO_ID
            if(i > 0){
                //if (!listaInvalidos.contains((int) identificacion.intValue())) {    
                    tipoId = new BigDecimal(infoBuro[0]);
                    fr_Segmento = new BigDecimal(infoBuro[6].trim());
                    identificacion = new BigDecimal(infoBuro[1]);
                    nombre=infoBuro[2] ;
                    
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMYPN249", tipoId.toString().trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMYPN250", identificacion.toString().trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.ExternasAlfanumericas.DUMYET250", nombre.trim());
                    
                    //Fr_Monto_del_Credito
                    estructuraSIS.put("Formulario.Estandar.SpareFormularioNumericaSparformn001",infoBuro[3].trim());
                    //Fr_Tipo_Consulta 4
                    estructuraSIS.put("Formulario.Estandar.SpareFormularioNumericaSparformn030",infoBuro[4].trim());
                    //Fr_oficina 5
                    estructuraSIS.put("Formulario.Estandar.SpareFormularioNumericaSparformn031",infoBuro[5].trim());
                    //FR_Segmento 6
                    estructuraSIS.put("Formulario.Estandar.SpareFormularioTextoSparformt030", Integer.toString(fr_Segmento.intValue()));

                    
                    estructuraSIS.put("Buro.Scores.Microcredito.C02SCR014TO", infoBuro[7].trim());
                    estructuraSIS.put("Buro.Demograficos.Demograficos.C00DEM03400", infoBuro[8].trim());
                    estructuraSIS.put("Buro.Demograficos.Demograficos.C01DEM032TO", infoBuro[9].trim());
                    estructuraSIS.put("Buro.Demograficos.Demograficos.C01DEM034TO", infoBuro[10].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos12Meses.C01MOR109HP", infoBuro[11].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos12Meses.C01MOR109IN", infoBuro[12].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos12Meses.C01MOR109RO", infoBuro[13].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe30DiasEnLosUltimos12Meses.C01MOR109VE", infoBuro[14].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe60DiasEnLosUltimos12Meses.C01MOR110HP", infoBuro[15].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe60DiasEnLosUltimos12Meses.C01MOR110IN", infoBuro[16].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe60DiasEnLosUltimos12Meses.C01MOR110RO", infoBuro[17].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe60DiasEnLosUltimos12Meses.C01MOR110VE", infoBuro[18].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111HP", infoBuro[19].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111IN", infoBuro[20].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111RO", infoBuro[21].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe90DiasEnLosUltimos12Meses.C01MOR111VE", infoBuro[22].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe120DiasOPeorEnLosUltimos12Meses.C01MOR112HP", infoBuro[23].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe120DiasOPeorEnLosUltimos12Meses.C01MOR112IN", infoBuro[24].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe120DiasOPeorEnLosUltimos12Meses.C01MOR112RO", infoBuro[25].trim());
                    estructuraSIS.put("Buro.Morosidad.MorasDe120DiasOPeorEnLosUltimos12Meses.C01MOR112VE", infoBuro[26].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionBReporteMasReciente.C01SUP004SC", infoBuro[27].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionBReporteMasReciente.C01SUP004SH", infoBuro[28].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionBReporteMasReciente.C01SUP004SM", infoBuro[29].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionBReporteMasReciente.C01SUP004SS", infoBuro[30].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionCReporteMasReciente.C01SUP007SC", infoBuro[31].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionCReporteMasReciente.C01SUP007SH", infoBuro[32].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionCReporteMasReciente.C01SUP007SM", infoBuro[33].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionCReporteMasReciente.C01SUP007SS", infoBuro[34].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionDReporteMasReciente.C01SUP010SC", infoBuro[35].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionDReporteMasReciente.C01SUP010SH", infoBuro[36].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionDReporteMasReciente.C01SUP010SM", infoBuro[37].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionDReporteMasReciente.C01SUP010SS", infoBuro[38].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionEReporteMasReciente.C01SUP013SC", infoBuro[39].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionEReporteMasReciente.C01SUP013SH", infoBuro[40].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionEReporteMasReciente.C01SUP013SM", infoBuro[41].trim());
                    estructuraSIS.put("Buro.Super.ProductosCalificacionEReporteMasReciente.C01SUP013SS", infoBuro[42].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.ExternasNumericas.DUMMYEN02", infoBuro[43].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.ExternasAlfanumericas.DUMMYET01", infoBuro[44].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN01", infoBuro[45].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN02", infoBuro[46].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN04", infoBuro[47].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN06", infoBuro[48].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN08", infoBuro[49].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN10", infoBuro[50].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN27", infoBuro[51].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN28", infoBuro[52].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN29", infoBuro[53].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN30", infoBuro[54].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN31", infoBuro[55].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN32", infoBuro[56].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN33", infoBuro[57].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN34", infoBuro[58].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN35", infoBuro[59].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN36", infoBuro[60].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN37", infoBuro[61].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN38", infoBuro[62].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN39", infoBuro[63].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN40", infoBuro[64].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN41", infoBuro[65].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN42", infoBuro[66].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN43", infoBuro[67].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN44", infoBuro[68].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN45", infoBuro[69].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN46", infoBuro[70].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN47", infoBuro[71].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN48", infoBuro[72].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN49", infoBuro[73].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN50", infoBuro[74].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN51", infoBuro[75].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN52", infoBuro[76].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN53", infoBuro[77].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN54", infoBuro[78].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN55", infoBuro[79].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN56", infoBuro[80].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN57", infoBuro[81].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN58", infoBuro[82].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN59", infoBuro[83].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN60", infoBuro[84].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN61", infoBuro[85].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN62", infoBuro[86].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN63", infoBuro[87].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN64", infoBuro[88].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN65", infoBuro[89].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN66", infoBuro[90].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN67", infoBuro[91].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN68", infoBuro[92].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN69", infoBuro[93].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN70", infoBuro[94].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN74", infoBuro[95].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Numericas.DUMMYPN75", infoBuro[96].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Alfanumericas.DUMMYPT71", infoBuro[97].trim());
                    estructuraSIS.put("Buro.VariablesPersonalizadas.Alfanumericas.DUMMYPT72", infoBuro[98].trim());

                    // Escritura de archivo txt Batch SIS por filas
                    for (Map.Entry<String, String> entry : estructuraSIS.entrySet()) {
                        if (!entry.getKey().equals("null")) {
                            lineaArchivo = lineaArchivo + entry.getValue() + "|";
                        }
                    }

                    lineaArchivo = lineaArchivo.substring(0, lineaArchivo.length());                    
                /*} else {
                    System.out.println("Registro invalido: " + identificacion + " - " + nombre);
                }*/
            } else{
                lineaArchivo = encabezadosSIS;
                //procesarArchivo.crearArchivoBatchSISContinuo(informacionBuro, encabezadosSIS);
            }
            i++;
            listaDatosArchivoSIS.add(lineaArchivo);
        }
        procesarArchivo.crearArchivoBatchSIS(PATH_FILE_BATCH+"SIS_" + informacionBuro, listaDatosArchivoSIS);
    }
    
    
    public void crearArchivoSalidaBatch(String informacionBuro){
        
        ProcesarArchivoTexto procesarArchivo = new ProcesarArchivoTexto();
        ArrayList<String> filasInformacionSalida = procesarArchivo.leerArchivoTxt(new File(PATH_FILE_BATCH_OUT+informacionBuro));
        
        LinkedHashMap<String, String> archivoSalidaBatchSIS = new LinkedHashMap<>();
        int i = 0;
        
        ArrayList<String> listaArchivo = new ArrayList<String>();
        listaArchivo.add(encabezadoSalidaBatch);
        System.out.println("Inicio Archivo de salida");
        for(String filaBuro : filasInformacionSalida){
            String lineaArchivo = "";
            String[] infoSalida = filaBuro.split("\\|");
            Runtime garbage = Runtime.getRuntime();
            garbage.gc();
        
            if(i > 0){
                
                if(infoSalida.length > 1){
                
                    LinkedHashMap<String, String> estructuraSalidaSIS = new LinkedHashMap<>();
                    Diccionario_Salida_24482  Salida_24482 = new Diccionario_Salida_24482();
                    Salida_24482.setValues(infoSalida);
                    estructuraSalidaSIS = Salida_24482.get24482_BANCAMIAPOLCR_VR2_SALIDA();

                    archivoSalidaBatchSIS.put("TIPO_ID",estructuraSalidaSIS.get("Buro.VariablesPersonalizadas.Numericas.DUMYPN249"));
                    archivoSalidaBatchSIS.put("ID",estructuraSalidaSIS.get("Buro.VariablesPersonalizadas.Numericas.DUMYPN250"));
                    archivoSalidaBatchSIS.put("APELLIDO",estructuraSalidaSIS.get("Buro.VariablesPersonalizadas.ExternasAlfanumericas.DUMYET250"));
                    archivoSalidaBatchSIS.put("Decision",!estructuraSalidaSIS.get("Clasificacion").trim().equals("")? estructuraSalidaSIS.get("Clasificacion").substring(0,1):"");
                    archivoSalidaBatchSIS.put("Score",estructuraSalidaSIS.get("Puntaje"));
                    archivoSalidaBatchSIS.put("RESULTADO PROCESO REGISTRO","REGISTRO PROCESADO");
                    archivoSalidaBatchSIS.put("ALERTA",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit024"));
                    archivoSalidaBatchSIS.put("CALIFICACION_SUP_A_EXCL_BANCAMIA_6M",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit015"));
                    archivoSalidaBatchSIS.put("CALIFICACION_SUP_A_Y_B_BANCAMIA_6M",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit016"));
                    archivoSalidaBatchSIS.put("CAUSAL_INCUMPLIMIENTO",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit003"));
                    archivoSalidaBatchSIS.put("CAUSAL_PENDIENTE",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit004"));
                    archivoSalidaBatchSIS.put("CLASIFICACION_SALIDA",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit001"));
                    archivoSalidaBatchSIS.put("MENSAJE_CAUSAL",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit002"));
                    archivoSalidaBatchSIS.put("Microcredito interno",estructuraSalidaSIS.get("Buro.Scores.Microcredito.C02SCR014TO"));
                    archivoSalidaBatchSIS.put("Monto_de_Credito_SMMLV",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin003"));
                    archivoSalidaBatchSIS.put("OFICINA",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit022"));
                    archivoSalidaBatchSIS.put("PUNTAJE_CLASIFICACION",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin001"));
                    archivoSalidaBatchSIS.put("REQUISITOS",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit010"));
                    archivoSalidaBatchSIS.put("SEGMENTO",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit011"));
                    archivoSalidaBatchSIS.put("TIPO_CLIENTE",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit012"));
                    archivoSalidaBatchSIS.put("VAR_CALIFICACION",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit014"));
                    archivoSalidaBatchSIS.put("VAR_CALIFICACION_2",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit017"));
                    archivoSalidaBatchSIS.put("VAR_MORAS_O_EST_DESC_TELCOS_SUP_1_SMMLV_COD",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin041"));
                    archivoSalidaBatchSIS.put("VAR_MORAS_O_EST_DESC_TELCOS_SUP_1_SMMLV_TIT",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin039"));
                    archivoSalidaBatchSIS.put("VAR_MORA_PER_59",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin037"));
                    archivoSalidaBatchSIS.put("VAR_MORA_PER_60",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin038"));
                    archivoSalidaBatchSIS.put("VAR_TIPO_CONSULTA",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin040"));
                    archivoSalidaBatchSIS.put("Var_Bandera",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit009"));
                    archivoSalidaBatchSIS.put("Var_Calif_B_2do_Reporte",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin044"));
                    archivoSalidaBatchSIS.put("Var_Calif_B_Reporte_Recien",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin045"));
                    archivoSalidaBatchSIS.put("Var_Calif_B_Total",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin046"));
                    archivoSalidaBatchSIS.put("Var_Calif_C_2do_Reporte",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin047"));
                    archivoSalidaBatchSIS.put("Var_Calif_C_Reporte_Recien",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin048"));
                    archivoSalidaBatchSIS.put("Var_Calif_C_Total",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin049"));
                    archivoSalidaBatchSIS.put("Var_Calif_D_2do_Reporte",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin050"));
                    archivoSalidaBatchSIS.put("Var_Calif_D_Reporte_Recien",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin051"));
                    archivoSalidaBatchSIS.put("Var_Calif_D_Total",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin052"));
                    archivoSalidaBatchSIS.put("Var_Calif_E_2do_Reporte",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin053"));
                    archivoSalidaBatchSIS.put("Var_Calif_E_Reporte_Recien",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin054"));
                    archivoSalidaBatchSIS.put("Var_Calif_E_Total",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin055"));
                    archivoSalidaBatchSIS.put("Var_Codigo_Causal",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin018"));
                    archivoSalidaBatchSIS.put("Var_Consult_Ult_3m_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin034"));
                    archivoSalidaBatchSIS.put("Var_Consult_Ult_3m_Fin_Excluye_Bancamia",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin012"));
                    archivoSalidaBatchSIS.put("Var_Descalificantes_Real_Telcos_Cod",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin021"));
                    archivoSalidaBatchSIS.put("Var_Dictamen_Buro_Aprobado",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit006"));
                    archivoSalidaBatchSIS.put("Var_Dictamen_Buro_Estudio",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit007"));
                    archivoSalidaBatchSIS.put("Var_Dictamen_Buro_Rechazado",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit008"));
                    archivoSalidaBatchSIS.put("Var_Estado_Documento_Id",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin002"));
                    archivoSalidaBatchSIS.put("Var_Exclusion_Acierta",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit020"));
                    archivoSalidaBatchSIS.put("Var_Monto_SMLV",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin033"));
                    archivoSalidaBatchSIS.put("Var_Moras_120_O_Mas_Actual_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin007"));
                    archivoSalidaBatchSIS.put("Var_Moras_120_O_Mas_Hist_12_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin011"));
                    archivoSalidaBatchSIS.put("Var_Moras_30_Actual_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin004"));
                    archivoSalidaBatchSIS.put("Var_Moras_30_Hist_12_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin008"));
                    archivoSalidaBatchSIS.put("Var_Moras_60_Actual_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin005"));
                    archivoSalidaBatchSIS.put("Var_Moras_60_Hist_12_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin009"));
                    archivoSalidaBatchSIS.put("Var_Moras_90_Actual_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin006"));
                    archivoSalidaBatchSIS.put("Var_Moras_90_Hist_12_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin010"));
                    archivoSalidaBatchSIS.put("Var_Moras_Actual_Titular_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin026"));
                    archivoSalidaBatchSIS.put("Var_Moras_Cualquier_Alt_Ult_6M",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin036"));
                    archivoSalidaBatchSIS.put("Var_Moras_Hist_12_Titular_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin028"));
                    archivoSalidaBatchSIS.put("Var_Moras_Mayor_30_Dias_Real",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin017"));
                    archivoSalidaBatchSIS.put("Var_Moras_Mayor_60_Dias_Telcos",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin016"));
                    archivoSalidaBatchSIS.put("Var_Moras_Mayor_60_Dias_Telcos_Vig",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin024"));
                    archivoSalidaBatchSIS.put("Var_Moras_Sup_60_Ult_12M_Real_Telcos",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin019"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vig_120_O_Mas_Hist_6M_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin030"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vig_30_Hist_6M_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin056"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vig_60_Hist_6M_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin057"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vig_6M_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin031"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vig_90_Hist_6M_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin029"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vig_Cualquier_Alt_Real_Telcos",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin035"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vigentes_Financieras_Cod",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin023"));
                    archivoSalidaBatchSIS.put("Var_Moras_Vigentes_Telcom_Cod",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin025"));
                    archivoSalidaBatchSIS.put("Var_Num_Prod_Estado_Desc_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin014"));
                    archivoSalidaBatchSIS.put("Var_Num_Prod_Estado_Desc_Fin_Cod",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin022"));
                    archivoSalidaBatchSIS.put("Var_Num_Prod_Estado_Desc_Real",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin015"));
                    archivoSalidaBatchSIS.put("Var_Num_Prod_Estado_Desc_Vig_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin027"));
                    archivoSalidaBatchSIS.put("Var_Num_Prod_Estado_Desc_Vig_Real",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin032"));
                    archivoSalidaBatchSIS.put("Var_Oficina_Riesgo",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit023"));
                    archivoSalidaBatchSIS.put("Var_Productos_Experiencia_Fin",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin013"));
                    archivoSalidaBatchSIS.put("Var_Rechazado_O_Pendiente",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit019"));
                    archivoSalidaBatchSIS.put("Var_Reportes_Negativos",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin020"));
                    archivoSalidaBatchSIS.put("Var_Telcos_Saldos_Moras_SMMLV_Codeudor",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin043"));
                    archivoSalidaBatchSIS.put("Var_Telcos_Saldos_Moras_SMMLV_Titular",estructuraSalidaSIS.get("Estandar.SpareSalidaNumericaSparsalin042"));
                    archivoSalidaBatchSIS.put("Var_Tipo_Cliente_7",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit018"));
                    archivoSalidaBatchSIS.put("Var_Vigencia_Documento",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit013"));
                    archivoSalidaBatchSIS.put("Var_Vigencia_Documento_In",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit021"));
                    archivoSalidaBatchSIS.put("Version",estructuraSalidaSIS.get("Estandar.SpareSalidaTextoSparsalit005"));

                    
                    for (Map.Entry<String, String> entry : archivoSalidaBatchSIS.entrySet()) {
                        if (!entry.getKey().equals("null")) {
                            lineaArchivo = lineaArchivo + entry.getValue() + ";";
                        }
                    }

                    lineaArchivo = lineaArchivo.substring(0, lineaArchivo.length());
                    listaArchivo.add(lineaArchivo);
                    //procesarArchivo.crearArchivoBatchSISContinuo(nameFileSalida, lineaArchivo);
                }
                
            }/*else{
                procesarArchivo.crearArchivoBatchSISContinuo(nameFileSalida, encabezadoSalidaBatch);
            }*/
            i++;
            
        }
        procesarArchivo.crearArchivoBatchSIS(PATH_FILE_BATCH+"SALIDA_" + informacionBuro, listaArchivo);
        System.out.println("Finaliza escritura archivo::: SALIDA_" + informacionBuro);
        
    }
}

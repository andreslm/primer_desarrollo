/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejecucionbatchmotor;


import com.ejecucionbatchmotor.util.Archivo_1_11;
import com.ejecucionbatchmotor.util.EnumEstrategias;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author b05745a
 */
public class EjecucionBatchMotor {

    public static String package_class = "com.ejecucionbatchmotor.estrategias.";
    public static String method_Archivo_SIS = "crearArchivoBatchSIS";
    public static String method_Archivo_Batch_SIS = "crearArchivoSalidaBatch";
    
            
            
    public static void main(String[] args) throws SecurityException {
        
        
        args = new String[2];
        
        /*args[0]="3";    
        args[1]="out_SIS_24482_banval003225.CAR-sort.txt";
        //args[2]="SIS_15350_PREBA_GENERA_SALIDA.txt";*/
        
        
        
        args[0]="3"; 
        args[1]="out_SIS_15350_FINANDINA_BURO_.txt";
        //args[2]="15350_FINANDINA_BATCH.txt";
        
        
        try {                        
            
            //args[2]="finval290120.txt";
            if(args.length > 0) {
                // Validacion proceso se ha ejecutar
                if(args[0].equals("1")) { //Crear archivo 1-11             

                    String baseEjecutar = args[1];
                    //String nombreEstrategia = baseEjecutar.substring(0, baseEjecutar.length() - 11);
                    System.out.println("Creando archivo 1-11...");                
                    Archivo_1_11 archivo_1_11 = new Archivo_1_11();
                    archivo_1_11.crearArchivo(baseEjecutar);
                    System.out.println("Se creo el archivo 1-11 en la carpeta temporales: " + baseEjecutar.substring(0, baseEjecutar.length() - 4) + ".prn");  

                } else if(args[0].equals("2")) {
                    /*Instanciar refection*/
                    /*Generar clase*/
                    Class executeClass = Class.forName(package_class+EnumEstrategias.estrategiaByID(args[1]).getNombreEstrategia());
                    /*Instanciar clase*/
                    Object instans = executeClass.newInstance();
                    
                    /*Declarar parametros */
                    Class<?>[] paramTypes = {String.class};
                    /*Declarar Metodo*/
                    Method method = executeClass.getDeclaredMethod(method_Archivo_SIS, paramTypes);
                    
                    System.out.println("Creando archivo Batch SIS");
                    String informacionBuro = args[1];
                    /*Invocar Metodos*/
                    method.invoke(instans, informacionBuro); 
                    System.out.println("Finaliza archivo Batch SIS");

                } else if(args[0].equals("3")) {
                    
                    /*Instanciar refection*/
                    /*Generar clase*/
                    Class executeClass = Class.forName(package_class+EnumEstrategias.estrategiaByID(args[1]).getNombreEstrategia());
                    /*Instanciar clase*/
                    Object instans = executeClass.newInstance();
                    /*Declarar parametros */
                    Class<?>[] paramTypes = {String.class};
                    /*Declarar Metodo*/
                    Method method = executeClass.getDeclaredMethod(method_Archivo_Batch_SIS, paramTypes);
                    String informacionBuro = args[1];
                    method.invoke(instans, informacionBuro);

                }else{ // Si los parametros son incorrectos

                    System.out.println("Parametros de ejecucion invalidos");

                }
            } else { // Si no se envian parametros
                System.out.println("No se tienen parametros de ejecucion");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(EjecucionBatchMotor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchMethodException ex) {
            Logger.getLogger(EjecucionBatchMotor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(EjecucionBatchMotor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(EjecucionBatchMotor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvocationTargetException ex) {
            Logger.getLogger(EjecucionBatchMotor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(EjecucionBatchMotor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
